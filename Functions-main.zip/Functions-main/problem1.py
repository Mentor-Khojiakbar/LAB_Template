#Write the solution of the first exercise here
