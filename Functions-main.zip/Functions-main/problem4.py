#Write the solution of the fourth exercise here
