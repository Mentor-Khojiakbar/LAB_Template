#Write the solution of the third exercise here
