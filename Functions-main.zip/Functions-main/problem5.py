#Write the solution of the fifth problem here
