#Write the solution of the second exercise here
